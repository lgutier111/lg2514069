/* 
 * File:   main.cpp
 * Author: Leo Gutierrez
 * Gaddis 7th Edition Chapter 2 Problem 17
 * Stock Commission - Display results of a stock purchase.
 *
 * Created on January 14, 2014, 9:02 AM
 */

//System libraries
#include <iostream>
using namespace std;

//Global Constants

//Functional Prototypes

//Begin program
int main() {

    //Declare variables
    int shares=600;                      //Number of shares
    float price=21.77,                   //Cost per share
          comm=.02,                      //Broker commission
          amtStock,                      //Cost of stock before commission 
          amtComm,                       //Total commission paid
          totSale;                       //Total stock + commission
    
    //Calculate the cost of the stock
    amtStock = shares*price;
    
    //Calculate the broker's commission
    amtComm = amtStock*comm;
    
    //Calculate the total sale of the stock
    totSale = amtStock+amtComm;
    
    //Display the detail of the stock purchase
    cout<<"The amount of the stock is "<<amtStock<<endl;
    cout<<"The brokers commission is "<<amtComm<<endl;
    cout<<"Total cost of the stock is "<<totSale<<endl;
    
    
    //Exit stage left     
    return 0;
}

