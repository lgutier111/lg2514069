/* 
 * File:   main.cpp
 * Author: Leo Gutierrez
 * Gaddis 7th Edition Chapter 2 Problem 9
 * Cyborg data type sizes - Find the number of bytes the data
 * types use on this computer.
 * Created on January 13, 2014, 4:39 PM
 */

//System Libraries
#include <iostream>
using namespace std;

//Global Constants

//Functional Prototypes

//Begin program here
int main() {
    //Display bytes for char data type
    cout<<"The size of a char data type is "<<sizeof(char)<<endl;
    
    //Display bytes for int data type
    cout<<"The size of a int data type is "<<sizeof(int)<<endl;
    
    //Display bytes for float data type
    cout<<"The size of a float data type is "<<sizeof(float)<<endl;
    
    //Display bytes for double data type
    cout<<"The size of a double data type is "<<sizeof(double)<<endl;
    
    //Exit program
    return 0;
}

