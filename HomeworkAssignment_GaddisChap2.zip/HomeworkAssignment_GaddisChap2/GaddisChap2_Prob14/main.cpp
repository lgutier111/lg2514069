/* 
 * File:   main.cpp
 * Author: Leo Gutierrez
 * Gaddis 7th Edition Chapter 2 Problem 14
 * Personal information - Display information using only a single
 * cout statement.
 *
 * Created on January 14, 2014, 8:44 AM
 */

//System libraries
#include <iostream>
using namespace std;

//Global Constants

//Functional Prototypes

//Begin program
int main() {

    //Display information
    cout<<"Leo Gutierrez\n"<<"123 Mickey Mouse Ln\n"<<"Corona, Ca 92880\n"
        <<"(959) 287-6169"<<endl;

    //Exit stage left
    return 0;
}

