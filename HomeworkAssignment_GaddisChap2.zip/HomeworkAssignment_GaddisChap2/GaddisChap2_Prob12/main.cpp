/* 
 * File:   main.cpp
 * Author: Leo Gutierrez
 * Gaddis 7th Edition Chapter 2 Problem 12
 * Land Calculation - Determine the number of acres
 *
 * Created on January 14, 2014, 8:32 AM
 */

//System libraries
#include <iostream>
using namespace std;

//Global Constants
int acre=43560;                         //1 acre = 43560 sq ft

//Functional Prototypes

//Begin program
int main(int argc, char** argv) {

    //Declare variables
    float tract=389767,                 //Number of sq ft in tract
          totAcres;                     //Total acres 
    
    //Calculate number of acres
    totAcres = tract/acre;
    
    //Display total number of acres
    cout<<"The total acres for the tract of land is "<<totAcres<<endl;
    
    //Exit stage right
    return 0;
}

