/* 
 * File:   main.cpp
 * Author: Leo Gutierrez
 * Gaddis 7th Edition Chapter 2 Problem 10
 * Miles Per Gallon - Determine the miles per gallon *
 * Created on January 14, 2014, 8:22 AM
 */

//System libraries
#include <iostream>
using namespace std;

//Global Constants

//Functional Prototypes

//Begin program
int main(int argc, char** argv) {

    //Declare variables
    short drvnMiles = 350,              //Miles driven
            gallons = 12,               //Gallons in car
            mpg;                        //Miles per gallon
    
    //Compute Miles per gallon
    mpg = drvnMiles/gallons;
            
    //Display miles per gallon
    cout<<"The car gets "<<mpg<<" miles per gallon"<<endl;
    
    //Exit program
        return 0;
}

