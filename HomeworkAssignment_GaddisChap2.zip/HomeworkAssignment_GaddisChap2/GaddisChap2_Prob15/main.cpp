/* 
 * File:   main.cpp
 * Author: Leo Gutierrez
 * Gaddis 7th Edition Chapter 2 Problem 15
 * Triangle Pattern - Display a triangle pattern on the screen
 *
 * Created on January 14, 2014, 8:52 AM
 */

//System libraries
#include <iostream>
using namespace std;

//Global Constants

//Functional Prototypes

//Begin program 
int main(int argc, char** argv) {

    //Display a triangle pattern with asterisks
    cout<<"   *   "<<endl;
    cout<<"  ***  "<<endl;
    cout<<" ***** "<<endl;
    cout<<"*******"<<endl;
    
    //Exit stage left
    return 0;
}

