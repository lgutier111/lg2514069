/* 
 * File:   main.cpp
 * Author: Leo Gutierrez
 * Project 1 - SIMON game
 * 
 * Object - to remember the sequence pattern flashed on the screen 
 *      and input the same sequence pattern on the keyboard for as 
 *      long as possible up to an iteration of 10.
 * 
 * Created on January 30, 2014, 5:34 PM
 */

//System Libraries
#include <iostream>
#include <ctime>
#include <cstdlib>
#include <string>
using namespace std;

//Global Constants

//Function Prototypes
void disGame ();                                //Display initial game screen
void disGame (char [], int);                    //Display game screen
void disGame (char &, char &, char &, char &);  //Display reinit screen
int getRndm ();                                 //Get random # 1-4
void makeAray (char [], int);                   //Create Simon array
int getUsrIn (char [], int);                    //user input and fill array
bool compare (char [], char [], int);           //Compare usr vs Simon arrays
void advDis ();                                 //Scroll display & wait a sec

//Begin Program
int main() {

    //Declare Variables
    const int SIZE = 10;                                //***Array limit.***
    int validL = 0, n = 1;
    char simon[SIZE], user[n];
    bool result;
    int score = 0;

    disGame();                                      //Display initial screen
    
    //Display initial message to let the user know to turn on caps lock key
    cout << "***** TURN ON THE CAPS LOCK KEY *****\n";
    cout << "*****     TO PLAY THIS GAME     *****\n\n";
    cout << "\n\n\n  READY TO PLAY...   HIT ENTER... \n";
    cin.get();
    
    //Set the random number generator
    srand(static_cast<unsigned int>(time(0)));
    
    //Create an array with SIZE elements and populate the whole thing now
    makeAray(simon, SIZE);
     
    //Loop here while the pattern entered by the user still matches the Simon
    //array or the user has entered the complete pattern of SIZE columns
    do{
        //Begin playing the game until the pattern by the user is broken
        advDis ();                      //Advance screen to clear it and wait
        disGame ();                     //Display with all *
        advDis ();                      //Advance screen to clear it and wait
        disGame (simon, n);             //Display with 1 character of pattern

        //Get the user input pattern up to the nth iteration
        validL = getUsrIn(user, n);
    
        //Validate user input
        if (validL == 1)
            result = compare(simon, user, n);
        else
            result = false;
        
        //Validate of win or loose to display the proper score
        if ((n <= SIZE) && (result == false))
            score = n - 1;
        else
            score = n;
        
        //Increment iteration
        n++;
        
}while ((result != false) && (n <= SIZE));
    
    //If result is false - user looses the game otherwise they're a winner.
    if (!result) 
        cout << "You lost the game.  Thank you for playing!\n";
    else
        cout << "You Win!!!!!\n";

    //Display the score
    cout << "Your score is : " << score << endl;
        
    //Exit stage left
    return 0;
}

//This function is called by main.  It displays the game board on the screen.
void disGame (){
    
    //Declare and initialize the variables
    char A1 = ' ', B1 = ' ', A2 = ' ', B2 = ' ';
    
    //Display the game
    cout << "            S I M O N          \n\n";
    cout << "\t" << A1 << "\t" << "|\t" << B1 << "\n\n";
    cout << "   ----------" << "\t+   ----------\n\n";
    cout << "\t" << A2 << "\t" << "|\t" << B2 << "\n\n\n";

}

//This function is called by disGame to reset the values of the 4 squares
// to spaces.  
void disGame (char &X1, char &X2, char &X3, char &X4){
    //Declare and initialize the variables
    //  char A1 = ' ', B1 = ' ', A2 = ' ', B2 = ' ';
      
    //Re-initialize all 4 squares to an spaces.
      X1 = X2 = X3 = X4 = ' ';
    
    //Display the game
    cout << "            S I M O N          \n\n";
    cout << "\t" << X1 << "\t" << "|\t" << X2 << "\n\n";
    cout << "   ----------" << "\t+   ----------\n\n";
    cout << "\t" << X3 << "\t" << "|\t" << X4 << "\n\n\n";
}

//This function displays one of the letters and then calls a reset screen
//to space everything out again before displaying the next letter.
void disGame (char simon[],int n){
    
    //Declare and initialize the variables
    char A1 = ' ', B1 = ' ', A2 = ' ', B2 = ' ';
    char X;
    
    //Read the array 1 by 1 up until n to display each letter within the
    //iteration.
    for (int x = 0; x < n; x++){
        X = simon[x];
    
        if (X == 'G')
            A1 = 'G';
        else if (X == 'R')
            B1 = 'R';
        else if (X == 'Y')
            A2 = 'Y';
        else
            B2 = 'B';

        //Display the game
        cout << "            S I M O N          \n\n";
        cout << "\t" << A1 << "\t" << "|\t" << B1 << "\n\n";
        cout << "   ----------" << "\t+   ----------\n\n";
        cout << "\t" << A2 << "\t" << "|\t" << B2 << "\n\n\n";
        
        //Delay putting out the reset of the screen for a couple of seconds 
        //before showing the next letter then scroll down.
        advDis ();
        disGame (A1, B1, A2, B2);
        
        //Delay refreshing the screen for a couple of seconds and the scroll 
        //down.
        advDis ();
    }
}


//This function is called by main.  It fills an array with random letters 
//based on an integer value coming back.
void makeAray (char simon[],int SIZE){
    //Declare variables
    int numLtr;
    
    //Get a random integer and send it back to populate the array.
    //Calls the random function.  Based on the number 1 - 4 will assign a 
    //letter to represent color (G)reen (R)ed (Y)ellow and (B)lue
    for (int count = 0; count < SIZE; count++){
        numLtr = getRndm();
        switch (numLtr){
            case 1 : simon[count] = 'G';                //G for Green
                     break;
            case 2 : simon[count] = 'R';                //R for Red
                     break;
            case 3 : simon[count] = 'Y';                //Y for Yellow
                     break;
            case 4 : simon[count] = 'B';                //B for Blue
                     break;
        }
   }    
}

//Get a random number 1 - 4 to use to populate the pattern in the Simon array. 
int getRndm(){
    
    return 1 + rand()%4;                        //Limit the number from 1 -4
}

//This function is called by main.  Prompt user for the current pattern and
//validate the entry.
int getUsrIn(char user[], int n){

    //Declare variable
    string input;
    int len, goodL;
    
    //Prompt user to enter the pattern
    cout << "Enter the pattern ===> ";
    cin >> input;
    
    //Populate the user array with the input variable character by character.
    for (int x = 0; x < n; x++){
        user[x] = input[x];
    }    
    
    //Test length of the input.  It must be equal to current iteration.
    len = input.length();
    (len == n) ? goodL = 1 : goodL = 0; 
    
    //Return 1 if the length is good, otherwise it returns 0.
    return goodL;
}

//This function is called by main.  It will compare the Simon array vs the
//user array to the nth column and return true or false.
bool compare (char simon [], char user [], int n){
    
    //Declare variables
    bool outcome = true;              //Return value
    string simonL, userL;             //Variables to hold comparison values.
    
    //Populate a variable from the Simon array up to the nth iteration.
    for (int x = 0; x < n; x++){
        simonL += simon[x];
    }
    
    //Populate a variable from the user array up to the nth iteration.
    for (int y = 0; y < n; y++){
        userL += user[y];
    }
    
    //Compare the variables and return T or F.
    (simonL == userL) ? outcome = true : outcome = false;
    
    //Exit function
    return outcome;
}

//This function is called by main and disGame to advance the lines down 20 
//lines and wait a couple of seconds to hold the screen to view
void advDis (){
    
    for (int i = 1; i < 300000000; i++);   //Wait a couple of seconds
    for (int j = 1; j < 21; j++){          //Push down 20 lines to clear scrn
        cout << "\n";
    }
}